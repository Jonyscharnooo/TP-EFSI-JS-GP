import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

function Detalle() {
  const [product, setProduct] = useState(null);
  const { id } = useParams();

  useEffect(() => {
    axios
      .get(`https://dummyjson.com/products/${id}`)
      .then((response) => {
        setProduct(response.data);
      })
      .catch((error) => {
        console.error('Error fetching data from API:', error);
      });
  }, [id]);

  if (!product) {
    return <div>Cargando...</div>;
  }

  return (
    <div>
      <img src={product.thumbnail} className="card-img-top imagenDetalle" alt={product.title} />
      <div className="container text-center detalle">
        <div className="row">
          <div className="col">
            <img src={product.thumbnail} className="card-img-top imagenDetalle" alt={product.title} />
          </div>
          <div className="col">
            <ul className='text-center centrar'>
              <h1>{product.title}</h1>
              <h2>Precio: {product.price} RP</h2>
              <h2>Descripcion: {product.description}</h2>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Detalle;