import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

function Detalle() {
  const [product, setProduct] = useState(null);
  const { id } = useParams();


  useEffect(() => {
    axios
      .get(`https://dummyjson.com/products/${id}`)
      .then((response) => {
        setProduct(response.data);
      })
      .catch((error) => {
        console.error('Error fetching data from API:', error);
      });
  }, [id]);

  return (
    <>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
        <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
      </head>
      <body className="p-3 m-0 border-0 bd-example m-0 border-0">
        <div className="container text-center detalle">
          <div className="row">
            <div className="col">
              <img src={product.thumbnail} className="card-img-top imagenDetalle" alt={product.title} />
            </div>
            <div className="col">
              <ul className='text-center centrar'>
                <h1>{product.title}</h1>
                <h2>Precio: {product.price} RP</h2>
                <h2>Nombre: {product.title}</h2>
              </ul>
            </div>
          </div>
        </div>
      </body>
    </>
  );
}

export default Detalle;
