import './App.css';
import { Link, Outlet } from 'react-router-dom';
import "./style.css"
import "./style2.css"

function Layout() {
  return (
    <>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
      </head>
      <body>
      <nav className="navbar navbar-expand-lg navbar-light ftco_navbar bg-lightblue ftco-navbar-light" id="ftco-navbar">
        <div className="container">
          <div className="collapse navbar-collapse" id="ftco-nav">
            <ul className="navbar-nav mr-auto">
              <li className="nav-item"><Link to='/' className='nav-link'>INICIO</Link></li>
              <li className="nav-item"><Link to='productos' className='nav-link'>PRODUCTOS</Link></li>
            </ul>
          </div>
        </div>
      </nav>
      <Outlet />
      </body>
    </>
  );
}
export default Layout;