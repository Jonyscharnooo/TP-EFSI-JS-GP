import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom'; 

function Productos() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');

  useEffect(() => {
    axios
      .get('https://dummyjson.com/products/categories')
      .then((response) => {
        setCategories(response.data);
      })
      .catch((error) => {
        console.error('Error fetching categories from API:', error);
      });

    axios
      .get('https://dummyjson.com/products')
      .then((response) => {
        setProducts(response.data.products);
      })
      .catch((error) => {
        console.error('Error fetching data from API:', error);
      });
  }, []);

  const filterProductsByCategory = (category) => {
    setSelectedCategory(category);
  };

  const filteredProducts = selectedCategory
    ? products.filter((product) => product.category === selectedCategory)
    : products;

  return (
    <>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
          rel="stylesheet"
        />
        <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
      </head>
      <body className="p-3 m-0 border-0 bd-example m-0 border-0">
        <form action="#" className="searchform order-lg-last">
          <div className="form-group d-flex">
            <select
              className="form-select form-select-lg mb-1"
              aria-label="Small select example"
              onChange={(e) => filterProductsByCategory(e.target.value)}
            >
              <option value="" selected>
                Categorias
              </option>
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
            <input type="text" className="form-control pl-3" placeholder="Search" />
            <button type="submit" className="form-control search">
              <span className="fa fa-search"></span>
            </button>
          </div>
        </form>
        <br />
        <div className="product-grid">
          {filteredProducts.map((product, index) => (
            <div key={index} className="product-card">
              <img
                src={product.thumbnail}
                alt={product.title}
                className="product-image"
              />
              <div className="product-details">
                <h3 className="product-title">{product.title}</h3>
                <p className="product-description">{product.description}</p>
                <p className="product-price">Price: {product.price}</p>
                <div key={product.id}>
                <Link to={`/detalle/${product.id}`}>
                  <button className="product-detail-button">Ver Detalles</button>
                </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </body>
    </>
  );
}

export default Productos;
