import React, { useState, useEffect } from 'react';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import axios from 'axios';
import './carrusel.css';

function Carrusel() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios
      .get('https://dummyjson.com/products')
      .then((response) => {
        const firstSixProducts = response.data.products.slice(0, 6);
        setProducts(firstSixProducts);
      })
      .catch((error) => {
        console.error('Error fetching product data from API:', error);
      });
  }, []);

  return (
    <div className="carrusel-container">
      {products.length > 0 ? (
        <Carousel showArrows autoPlay infiniteLoop showThumbs={false} dynamicHeight={true}>
          {products.map((product) => (
            <div key={product.id} className="carrusel-item">
              <img src={product.thumbnail} alt={product.title} />
              <p className="legend">{product.title}</p>
            </div>
          ))}
        </Carousel>
      ) : (
        <p>Cargando productos...</p>
      )}
    </div>
  );
}

export default Carrusel;