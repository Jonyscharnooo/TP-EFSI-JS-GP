import { Carousel } from 'react-carousel-minimal';

function Carusel() {
 const data = [
    {
      image: "https://cdn.hobbyconsolas.com/sites/navi.axelspringer.es/public/media/image/2018/05/nuevas-skins-lol-esports_2.jpg?tf=3840x",
      caption: "Beemo"
    },
    {
      image: "https://acis.org.co/portal/sites/default/files/Pyke.jpg",
      caption: "Proyecto Pyke"
    },
    {
      image: "https://images.contentstack.io/v3/assets/blt731acb42bb3d1659/blt449e04b3e3400606/61bbd19dc9ed2d27fb59ea97/Darkstar_Mordekaiser-HD.jpg",
      caption: "Mordekaiser Estrella Oscura"
    },
    {
      image: "https://www.esportmaniacos.com/wp-content/uploads/2021/11/FDMr8UNXIAIF5_V1-780x470.jpg",
      caption: "Gwen Monada de Cafeteria"
    },
    {
      image: "https://i.ytimg.com/vi/TcGYQrILZAs/maxresdefault.jpg",
      caption: "Brolaf"
    },
    {
      image: "https://pm1.aminoapps.com/7167/add04d993624c4dc6df2685d41fafd77e0b6b4b0r1-640-360v2_uhq.jpg",
      caption: "Zed Exterminador Galactico"
    }
  ];

  const captionStyle = {
    fontSize: '1.5em',
    fontWeight: 'bold',
  }
  return (
    <div className="App">
      <div style={{ textAlign: "center" }}>
        <div style={{
          padding: "0 20px"
        }}>
          <Carousel
            data={data}
            time={2000}
            width="850px"
            height="500px"
            captionStyle={captionStyle}
            radius="10px"
            slideNumber={false}
            captionPosition="top"
            automatic={true}
            dots={true}
            pauseIconColor="white"
            pauseIconSize="40px"
            slideBackgroundColor="darkgrey"
            slideImageFit="cover"
            thumbnails={true}
            thumbnailWidth="100px"
            style={{
              textAlign: "center",
              maxWidth: "850px",
              maxHeight: "500px",
              margin: "40px auto",
            }}
          />
        </div>
      </div>
    </div>
  );
}

export default Carusel;