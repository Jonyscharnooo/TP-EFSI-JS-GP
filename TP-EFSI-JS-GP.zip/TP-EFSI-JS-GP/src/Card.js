import React from "react";
import "./App.css"

export default function Card() {
    return (
        <>
            <div class="container text-center">
                <div class="row">
                    <div class="col">
                        <div className="card">
                            <img src="https://cdn.hobbyconsolas.com/sites/navi.axelspringer.es/public/media/image/2018/05/nuevas-skins-lol-esports_2.jpg?tf=3840x" className="card-img-top imagen" alt="..." />
                            <div className="card-body">
                                <h5 className="card-title">Beemo</h5>
                                <button className="btn btn-primary">Ver mas detalle de la skin</button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div className="card">
                            <img src="https://acis.org.co/portal/sites/default/files/Pyke.jpg" className="card-img-top imagen" alt="..." />
                            <div className="card-body">
                                <h5 className="card-title">Proyecto Pyke</h5>
                                <button className="btn btn-primary">Ver mas detalle de la skin</button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div className="card">
                            <img src="https://images.contentstack.io/v3/assets/blt731acb42bb3d1659/blt449e04b3e3400606/61bbd19dc9ed2d27fb59ea97/Darkstar_Mordekaiser-HD.jpg" className="card-img-top imagen" alt="..." />
                            <div className="card-body">
                                <h5 className="card-title">Mordekaiser Estrella Oscura</h5>
                                <button className="btn btn-primary">Ver mas detalle de la skin</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                <div class="col">
                        <div className="card">
                            <img src="https://www.esportmaniacos.com/wp-content/uploads/2021/11/FDMr8UNXIAIF5_V1-780x470.jpg" className="card-img-top imagen" alt="..." />
                            <div className="card-body">
                                <h5 className="card-title">Gwen Monada de Cafeteria</h5>
                                <button className="btn btn-primary">Ver mas detalle de la skin</button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div className="card">
                            <img src="https://i.ytimg.com/vi/TcGYQrILZAs/maxresdefault.jpg" className="card-img-top imagen" alt="..." />
                            <div className="card-body">
                                <h5 className="card-title">Brolaf</h5>
                                <button className="btn btn-primary">Ver mas detalle de la skin</button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div className="card">
                            <img src="https://pm1.aminoapps.com/7167/add04d993624c4dc6df2685d41fafd77e0b6b4b0r1-640-360v2_uhq.jpg" className="card-img-top imagen" alt="..." />
                            <div className="card-body">
                                <h5 className="card-title">Zed Exterminador Galactico</h5>
                                <button className="btn btn-primary">Ver mas detalle de la skin</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}