import './App.css';
import Carusel from './Carrusel';


function Home() {
  return (
    <>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
        <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
      </head>
      <body className="p-3 m-0 border-0 bd-example m-0 border-0">
    <h1>BIENVENIDO A LA MEJOR PAGINA DE SKINS DE LOL</h1>
    <img src="https://1000marcas.net/wp-content/uploads/2020/11/League-of-Legends-logo.jpg" width="40%"></img>
        <Carusel/>
      </body>
    </>
  );
}

export default Home;
