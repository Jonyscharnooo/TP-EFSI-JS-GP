import './App.css';
import Carusel from './Carrusel';

function Home() {
  return (
    <div className="container text-center">
      <h1>BIENVENIDO A LA MEJOR PAGINA DE VENTA DE SKINS DEL LOL (NO HAY STOCK)</h1>
      <img
        src="https://1000marcas.net/wp-content/uploads/2020/11/League-of-Legends-logo.jpg"
        alt="Logo de League of Legends"
        className="logo-image"
      />
      <Carusel />
    </div>
  );
}

export default Home;